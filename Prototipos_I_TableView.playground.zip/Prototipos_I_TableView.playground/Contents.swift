//: Cargamos las librerías principales, `UIKit` para las apps y `PlaygroundSupport` para interactuar con el *playground*.

import UIKit
import PlaygroundSupport

//: Creamos la clase `vistaTabla` que hereda de `UITableViewController`, la fuente de todo.
class vistaTabla:UITableViewController {
//: `datos` es nuestro *array* para la sección 1
    var datos = ["Fila Uno", "Fila Dos", "Fila Tres", "Fila Cuatro", "Fila Cinco"]
//: `datos2` es el *array* de datos para la sección 2
    var datos2 = ["Nueva sección Fila Uno", "Nueva sección Fila Dos", "Nueva sección Fila Tres"]
//: La función `numberOfSections` devuelve el total de secciones que tendrá nuestra tabla: **2**.
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
//: La función `tableView` tiene muchas versiones, pero la que usa el parámetro externo `numberOfRowsInSection` se encarga de indicar el número de filas en la sección.
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//: Si estamos en la sección 0 devolvemos el total de datos que hay en el *array* `datos`.
        if section == 0 {
            return datos.count
        } else if section == 1 {
//: Si estamos en la sección 1 devolvemos el total de datos que hay en el *array* `datos2`.
            return datos2.count
        }
        return 0
    }
    
//: La función `tableView` con el parámetro externo `cellForRowAt` es aquella que el sistema llama cada vez que tiene rellenar algún dato de una fila de la tabla, indicando en el parámetro `indexPath` la posición que se está solicitando.
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//: Creamos una celda `UITableViewCell` vacía del ancho de la tabla y de alto 100 puntos.
        let celda = UITableViewCell(frame: CGRect(origin: CGPoint.zero, size: CGSize(width: tableView.frame.size.width, height: 100)))
//: Creamos un etiqueta `UILabel` del tamaño de la celda.
        let etiqueta = UILabel(frame: celda.frame)
//: Usando un `switch` preguntamos por la sección. Si es la 0 devolvemos el dato del *array* `datos` y es la 1 del *array* `datos2`.
        switch indexPath.section {
        case 0:
            etiqueta.text = datos[indexPath.row]
        case 1:
            etiqueta.text = datos2[indexPath.row]
        default:()
        }
//: Añadimos la vista `etiqueta` (el objeto `UILabel`) a la celda, usando el método `addSubView` que tienen todas las vistas del sistema para incluir una en otra.
        celda.addSubview(etiqueta)
//: Devolvemos la celda
        return celda
    }
    
//: La función `tableView` con el parámetro `titleForHeaderInSection` nos permite dar un nombre a la sección, indicándonos cuál en el parámetro `section`.
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "Sección \(section + 1)"
    }
    
//: La función `tableView` con el parámetro `didSelectRowAt` es llamada cada vez que se toca una fila de la tabla, indicando cuál se ha tocado en el parámetro `indexPath` que recibe.
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//: Según la sección donde esté la fila pulsada, recuperamos el dato de un *array* o del otro.
        switch indexPath.section {
        case 0:
            print(datos[indexPath.row])
        case 1:
            print(datos2[indexPath.row])
        default:()
        }
    }
}

//: Creamos un controlador de navegación y lo asociamos con una instancia vacía de `vistaTabla` a la propiedad `liveView` de la página actual del Playground.
PlaygroundPage.current.liveView = UINavigationController(rootViewController: vistaTabla())
